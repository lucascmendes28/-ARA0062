<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>LB Guitarras</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/shop-homepage.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      
      
        
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="#">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="https://lucascmendes.000webhostapp.com/Trabalho/Pagina/sobrenos.html">Sobre nós</a>
          </li>
          
          <li class="nav-item">
            <a class="nav-link" href="https://lucascmendes.000webhostapp.com/Trabalho/Pagina/contato.html">Entre em Contato</a>
            <li class="nav-item">
            <a class="nav-link" href="https://lucascmendes.000webhostapp.com/Trabalho/menu.php">Cadastro Blog</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="https://lucascmendes.000webhostapp.com/Trabalho/menu.php">Login</a>
            
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">

    <div class="row">

      <div class="col-lg-3">

        <h1 class="my-4">L.B Guitarras</h1>
        

      </div>
      <!-- /.col-lg-3 -->

      <div class="col-lg-9">

        <div id="carouselExampleIndicators" class="carousel slide my-4" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner" role="listbox">
            <div class="carousel-item active">
              <img class="d-block img-fluid" src="https://images.pexels.com/photos/6966/abstract-music-rock-bw.jpg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="First slide">
            </div>
            <div class="carousel-item">
              <img class="d-block img-fluid" src="https://images.pexels.com/photos/1813124/pexels-photo-1813124.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=9400" alt="Second slide">
            </div>
            <div class="carousel-item">
              <img class="d-block img-fluid" src="https://images.pexels.com/photos/96380/pexels-photo-96380.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="Third slide">
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>

        <div class="row">

          <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100">
              <a href="#"><img class="card-img-top" src="https://madeinbrazil.fbitsstatic.net/img/p/guitarra-strato-tg530-woodstock-tagima-azul-laked-placid-blue-502-87267/273752.jpg?w=270&h=270&v=no-change" alt=""></a>
              <div class="card-body">
                <h4 class="card-title">
                  <a href="#">Guitarra STRATO ST-2 DBL Vintage Daphne Blue PH X</a>
                </h4>
                <h5>R$ 1.169,00 ou 10 x de R$ 116,90 sem juros</h5>
                
              </div>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100">
              <a href="#"><img class="card-img-top" src="https://madeinbrazil.fbitsstatic.net/img/p/guitarra-signature-scott-ian-king-v-kvxt-2916402555-jackson-127186/313671.jpg?w=800&h=800&v=no-change" alt=""></a>
              <div class="card-body">
                <h4 class="card-title">
                  <a href="#">Guitarra Signature Scott Ian KING V KVXT 2916402555 Jacksono</a>
                </h4>
                <h5>R$ 6.590,00 ou 10 x de R$ 659,00 sem juros</h5>
                
              </div>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100">
              <a href="#"><img class="card-img-top" src="https://madeinbrazil.fbitsstatic.net/img/p/guitarra-les-paul-special-ve-epiphone-sunburst-heritage-cherry-sunburst-hs-69421/255904.jpg?w=270&h=270&v=no-change" alt=""></a>
              <div class="card-body">
                <h4 class="card-title">
                  <a href="#">Guitarra Les Paul Special Ve Epiphone - Sunburst (Heritage Cherry Sunburst)</a>
                </h4>
                <h5>R$ 2.899,00 ou 10 x de R$ 289,90 sem juros</h5>
                
              </div>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100">
              <a href="#"><img class="card-img-top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTDOTwkVnSupIyY56iLDng2OPObeB_CVV3We5dxz7RZ-5WULwPMF_K7iqwSF7ATKOWGYQUGCSM&usqp=CAc" alt=""></a>
              <div class="card-body">
                <h4 class="card-title">
                  <a href="#">Violão Yamaha Silent Slg200n Crimson Red Burst</a>
                </h4>
                <h5>R$4.849 ou 10 x de R$ 484,90 sem juros</h5>
                
              </div>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100">
              <a href="#"><img class="card-img-top" src="https://madeinbrazil.fbitsstatic.net/img/p/violao-eletroacustico-nl39lcnt-phx-69815/256298.jpg?w=270&h=270&v=no-change" alt=""></a>
              <div class="card-body">
                <h4 class="card-title">
                  <a href="#">Violão Eletroacústico Nl39lcnt PHX</a>
                </h4>
                <h5>R$ 999,00 ou 10 x de R$ 99,90 sem juros </h5>
                
              </div>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100">
              <a href="#"><img class="card-img-top" src="https://madeinbrazil.fbitsstatic.net/img/p/violao-classico-yamaha-c45-yamaha-85046/271531.jpg?w=270&h=270&v=no-change" alt=""></a>
              <div class="card-body">
                <h4 class="card-title">
                  <a href="#">Violão Clássico Yamaha C45 Yamaha</a>
                </h4>
                <h5>R$ 1.089,00 ou 10 x de R$ 108,90 sem juros </h5>
                
              </div>
              
            </div>
          </div>
          
        <hr>
        <div class="row">
        <?php
            include_once("../servico/Bd.php");
            
            $bd = new Bd();
            
            $sql = "select * from blog";
            
            foreach ($bd->query($sql) as $row) {
                
                echo '        
                  <div class="card mr-5 mb-5" style="width: 18rem;">
                    <div class="card-body">
                    <h5 class="card-title">'.$row['titulo'].'</h5>
                    <p class="card-text">'.substr($row['corpo'],0,100).'...</p>
                    <a href="#" class="card-link">Leia mais</a>
                  </div>
                </div>
                ';
            }
        
        ?> 

        </div>
        <!-- /.row -->

      </div>
      <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Your Website 2020</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>