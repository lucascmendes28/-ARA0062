<?php
session_start();

$login = $_POST["login"];
$senha = $_POST["senha"];

if ($login=="admin" && $senha=="1234") {
    $_SESSION["autenticado"]=true;
    $html="
    <!doctype>
    <html>
	    <head> <title> Página de Verificação </title> </head>
	    <body>
		    <script> 
		        window.location.replace('https://lucascmendes.000webhostapp.com/Trabalho/menu.php')
		    </script>
	    </body>
    </html>
    ";
} else {
    session_destroy();
    $html="
<!doctype>
<html>
	<head> <title> Página de Verificação </title> </head>
	<body>
	    <h1>Seu login: $login e Sua Senha: $senha SÃO INVÁLIDOS</h1>
	</body>
</html> 
";
}
echo $html;
?>