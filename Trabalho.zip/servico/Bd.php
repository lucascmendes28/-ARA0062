<?php

class Bd {
    private $conn;
    
    function __construct() {
        $dsn = 'mysql:dbname=id14818767_aulaprofessor1111;host=localhost';
        $user = 'id14818767_lucascmendes';
        $password = 'W*PrvFE*+K0ff/Wc';
        
        try {
            $this->conn = new PDO($dsn, $user, $password);
        } catch (PDOException $e) {
            echo 'Connection failded: ' . $e->getMessage();
        }
    }
    
    function query($sql) {
        try {
            return $this->conn->query($sql);
        } catch (PDOException $e) {
            echo 'Query failded: ' . $e->getMessage();
        }
    }
    
        function exec($sql) {
        try {
            return $this->conn->exec($sql);
        } catch (PDOException $e) {
            echo 'Query failded: ' . $e->getMessage();
        }
    }
    
}


?>